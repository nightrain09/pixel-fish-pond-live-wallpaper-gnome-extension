// Sinh LivelyProperties.json và js/generated.js từ tools/settings-spec.js và các thư mục sun/ moon/ fish/.
// Chạy lại mỗi khi sửa settings-spec.js hoặc thêm / bớt / đổi tên file trong fish/, sun/, moon/:
//     node tools/build.mjs
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath, pathToFileURL} from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const {SPEC} = await import(pathToFileURL(path.join(root, 'tools', 'settings-spec.js')).href);

const natural = (a, b) => a.localeCompare(b, undefined, {numeric: true, sensitivity: 'base'});
const MAX_PER_FILE = 30;
const MAX_CUSTOM_FISH = 60;

// ── quét tài nguyên ──
const listDir = d => {
    try {
        return fs.readdirSync(path.join(root, d), {withFileTypes: true});
    } catch (_e) {
        return [];
    }
};
const pngs = d => listDir(d).filter(e => e.isFile() && /\.png$/i.test(e.name))
    .map(e => `${d}/${e.name}`).sort(natural);

const sun = pngs('sun');
const moon = pngs('moon');

// fish/<loài>/<tên>.png|.json (hoặc đặt thẳng trong fish/)
const groups = new Map();
const addFiles = (species, dir) => {
    for (const e of listDir(dir)) {
        if (!e.isFile() || e.name.startsWith('.')) continue;
        const m = /^(.+)\.(png|json)$/i.exec(e.name);
        if (!m) continue;
        const id = species ? `${species}/${m[1]}` : m[1];
        let g = groups.get(id);
        if (!g) groups.set(id, g = {id, species, name: m[1], png: null, json: null, sig: ''});
        const rel = `${dir}/${e.name}`;
        if (m[2].toLowerCase() === 'png') {
            g.png = rel;
        } else {
            try {
                g.json = JSON.parse(fs.readFileSync(path.join(root, rel), 'utf8'));
            } catch (err) {
                console.warn(`! bỏ qua ${rel}: ${err.message}`);
            }
        }
        g.sig += `${e.name};`;
    }
};
addFiles('', 'fish');
for (const d of listDir('fish'))
    if (d.isDirectory() && !d.name.startsWith('.')) addFiles(d.name, `fish/${d.name}`);

const fish = [...groups.values()]
    .filter(g => g.png || g.json)
    .sort((a, b) => natural(a.species, b.species) || natural(a.name, b.name));

// khoá Lively cho số con của từng file cá: chỉ chữ / số / gạch dưới, không trùng nhau
const used = new Set();
for (const f of fish) {
    let k = 'fish_file_' + f.id.replace(/[^A-Za-z0-9]+/g, '_');
    while (used.has(k)) k += '_';
    used.add(k);
    f.key = k;
}

// ── LivelyProperties.json ──
const props = {};
for (const g of SPEC) {
    props[`_sec_${g.id}`] = {type: 'label', text: `── ${g.title} ──`};
    if (g.desc) props[`_desc_${g.id}`] = {type: 'label', text: g.desc};
    for (const r of g.rows) {
        const p = r.type === 'bool'
            ? {type: 'checkbox', text: r.title, value: r.def}
            : {type: 'slider', text: r.title, value: r.def, min: r.min, max: r.max, step: r.step};
        if (r.sub) p.help = r.sub;
        props[r.key] = p;

        // ngay sau công tắc "Use custom fish": số con của từng file trong fish/
        if (r.key === 'fish-use-custom') {
            if (!fish.length) {
                props._nofish = {type: 'label', text: 'No files in fish/ yet. Add some, then run: node tools/build.mjs'};
            }
            for (const f of fish) {
                props[f.key] = {
                    type: 'slider', text: `  ${f.id}`, value: 1, min: 0, max: MAX_PER_FILE, step: 1,
                    help: f.png ? 'Fish count (image + skeleton)' : 'Fish count (skeleton drawn by code)',
                };
            }
        }
    }
}
fs.writeFileSync(path.join(root, 'LivelyProperties.json'), JSON.stringify(props, null, 2) + '\n');

// ── js/generated.js ──
const rows = [];
const setters = [];
for (const g of SPEC) {
    for (const r of g.rows) {
        rows.push({key: r.key, name: r.name, type: r.type, def: r.def, min: r.min, max: r.max, structural: !!r.structural});
        if (r.name) setters.push(`    '${r.key}': v => { ${r.name} = v; },`);
    }
}
const assets = {
    sun, moon,
    fish: fish.map(({id, species, name, png, json, sig, key}) => ({id, species, name, png, json, sig, key})),
};
const gen = `// Sinh tự động bởi tools/build.mjs từ tools/settings-spec.js và các thư mục sun/ moon/ fish/. Đừng sửa tay.
const SETTING_ROWS = ${JSON.stringify(rows)};

const SETTERS = {
${setters.join('\n')}
};

const POND_ASSETS = ${JSON.stringify(assets)};
`;
fs.writeFileSync(path.join(root, 'js', 'generated.js'), gen);

console.log(`OK: ${rows.length} cài đặt, ${sun.length} ảnh mặt trời, ${moon.length} ảnh mặt trăng, ${fish.length} file cá` +
    (fish.length > MAX_CUSTOM_FISH ? ' (chỉ tối đa 60 con được dùng)' : ''));
