# Ao cá cho Lively Wallpaper

Bản chạy trên Windows của extension GNOME "Pond Wallpaper": ao cá koi pixel art với sóng nước thật
(giải phương trình sóng 2D), lá sen, lá rụng, rong, ngày đêm theo giờ máy, mặt trời / mặt trăng phản chiếu trên mặt nước.

## Cài đặt
1. Cài [Lively Wallpaper](https://www.rocksdanister.com/lively/) (bản Microsoft Store hoặc GitHub).
2. Kéo thả file `.zip` này vào cửa sổ Lively (hoặc **Add wallpaper → Open file**).
3. Chọn **Ao cá** làm hình nền.

## Cài đặt trong Lively
Bấm biểu tượng **Customise** (cây bút) trên ô Ao cá. Có đủ ~75 mục, chia nhóm giống bản GNOME:
Performance, Scene, Time of day, Sun & Moon, Water & Waves, Mouse, Fallen Leaves, Koi, Lily Pads.
Các mục đổi số lượng / độ phân giải sẽ dựng lại ao nhưng giữ nguyên vị trí cá và lá; đổi "Layout seed" thì ra bố cục mới.

**Chuột:** để click / kéo tạo sóng, bật **Settings → Wallpaper → Input → Mouse** trong Lively. Lively chỉ chuyển chuột
khi bạn bấm vào nền desktop (không phải vào cửa sổ).

**Hiệu năng:** tăng **Pixel size** (4 → 6) hoặc giảm **Maximum FPS** nếu máy yếu. Lively tự tạm dừng khi có cửa sổ phóng to / toàn màn hình.

## Thêm cá của riêng bạn
Cách làm file `.png` / `.json` giống bản GNOME (xem mục "Cá tuỳ chỉnh" trong README gốc: `facing`, `length`, `segments`, `wave`, `profile`...).
Khác một điểm: trang web không tự quét thư mục được, nên sau khi thêm / sửa / đổi tên / xoá file trong `fish/`, `sun/` hoặc `moon/` chạy:

```
node tools/build.mjs
```

(cần cài [Node.js](https://nodejs.org)). Lệnh này cập nhật `LivelyProperties.json` (mỗi file cá có một thanh trượt số con riêng, dưới công tắc
**Use custom fish**) và `js/generated.js`. Nếu bạn đã import vào Lively, chép thư mục đã sửa đè lên thư mục wallpaper trong
`Documents\Lively Wallpaper\Library\wallpapers\...`, rồi chọn lại wallpaper. Sửa nội dung `.json` / `.png` có sẵn mà không đổi tên thì chỉ cần chạy lại lệnh trên.

Nếu sửa `tools/settings-spec.js` (thêm / bớt cài đặt) cũng chạy lại `node tools/build.mjs`.

## Cấu trúc
```
index.html            trang chính
LivelyInfo.json       thông tin wallpaper cho Lively
LivelyProperties.json cài đặt hiện trong Customise (sinh tự động)
js/cairo-shim.js      lớp Cairo -> Canvas 2D
js/pond.js            lõi mô phỏng + vẽ (port nguyên từ extension.js)
js/main.js            nhận cài đặt từ Lively, chuột, vòng lặp
js/generated.js       danh sách cài đặt + tài nguyên (sinh tự động)
tools/                settings-spec.js + build.mjs
sun/ moon/ fish/      ảnh
```

## Khác bản GNOME
- Không có hiệu ứng ao trong màn hình Overview, và không có hộp Preferences riêng (dùng Customise của Lively).
- Canvas không tắt được khử răng cưa, nên viền hình tròn mềm hơn một chút so với bản gốc; ao vẫn được phóng to bằng `image-rendering: pixelated` nên giữ nét pixel.
- Bỏ các mục chỉ dành cho GNOME: độ trong suốt của nước (không có hình nền gốc bên dưới), log click (`journalctl`).
