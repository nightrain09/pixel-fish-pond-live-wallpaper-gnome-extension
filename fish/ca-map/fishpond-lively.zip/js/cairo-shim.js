// Lớp tương thích Cairo -> Canvas 2D.
// Lõi mô phỏng (pond.js) gốc viết cho GNOME Shell và vẽ bằng Cairo; file này cài lại đúng phần API Cairo
// mà lõi dùng, để giữ nguyên logic vẽ khi chạy trong trình duyệt (Lively Wallpaper).
//
// Khác biệt có chủ ý:
//  - setAntialias(NONE) bỏ qua: canvas không tắt được khử răng cưa. Ao vẽ ở độ phân giải thấp rồi phóng to
//    bằng image-rendering: pixelated, nên vẫn ra nét pixel.
//  - Filter.NEAREST áp cho lần paint kế tiếp bằng imageSmoothingEnabled = false.

const Cairo = (() => {
    const OPS = {
        OVER: 'source-over',
        SOURCE: 'copy',
        ATOP: 'source-atop',
        DEST_OUT: 'destination-out',
        MULTIPLY: 'multiply',
        CLEAR: 'clear',        // xử lý riêng bằng clearRect
    };

    const rgba = (r, g, b, a) =>
        `rgba(${Math.round(r * 255)},${Math.round(g * 255)},${Math.round(b * 255)},${a})`;

    const makeCanvas = (w, h) => {
        const c = document.createElement('canvas');
        c.width = Math.max(1, w | 0);
        c.height = Math.max(1, h | 0);
        return c;
    };

    class ImageSurface {
        constructor(_format, w, h) {
            this.canvas = makeCanvas(w, h);
        }

        // Bọc một canvas có sẵn (canvas hiển thị chính)
        static wrap(canvas) {
            const s = Object.create(ImageSurface.prototype);
            s.canvas = canvas;
            return s;
        }

        // Chép một ảnh đã tải xong (HTMLImageElement) vào một surface
        static fromImage(img) {
            const s = new ImageSurface(0, img.naturalWidth, img.naturalHeight);
            s.canvas.getContext('2d').drawImage(img, 0, 0);
            return s;
        }

        getWidth() { return this.canvas.width; }
        getHeight() { return this.canvas.height; }
    }

    class Gradient {
        constructor(kind, args) {
            this.kind = kind;
            this.args = args;
            this.stops = [];
        }

        addColorStopRGBA(off, r, g, b, a) {
            this.stops.push([off, rgba(r, g, b, a)]);
        }

        build(ctx) {
            const g = this.kind === 'linear'
                ? ctx.createLinearGradient(...this.args)
                : ctx.createRadialGradient(...this.args);
            for (const [o, c] of this.stops)
                g.addColorStop(o, c);
            return g;
        }
    }

    class LinearGradient extends Gradient {
        constructor(x0, y0, x1, y1) { super('linear', [x0, y0, x1, y1]); }
    }

    class RadialGradient extends Gradient {
        constructor(x0, y0, r0, x1, y1, r1) { super('radial', [x0, y0, r0, x1, y1, r1]); }
    }

    // bóng đơn sắc của một ảnh (dùng cho maskSurface), có nhớ lại để khỏi dựng lại mỗi khung
    const _silh = new WeakMap();
    function silhouette(img, color) {
        let m = _silh.get(img);
        if (!m)
            _silh.set(img, m = new Map());
        let c = m.get(color);
        if (!c) {
            c = makeCanvas(img.getWidth(), img.getHeight());
            const x = c.getContext('2d');
            x.fillStyle = color;
            x.fillRect(0, 0, c.width, c.height);
            x.globalCompositeOperation = 'destination-in';
            x.drawImage(img.canvas, 0, 0);
            m.set(color, c);
        }
        return c;
    }

    class Context {
        constructor(surface) {
            this.surface = surface;
            this.ctx = surface.canvas.getContext('2d');
            this.W = surface.canvas.width;
            this.H = surface.canvas.height;
            this.st = {src: {kind: 'color'}, nearest: false, op: 'source-over', color: 'rgba(0,0,0,1)'};
            this.stack = [];
            this.groups = [];     // các nhóm đang dựng: {ctx, prev}
            this.pool = [];       // canvas tạm dùng lại theo độ sâu lồng nhau
            this.lastGroup = null;
        }

        // ── trạng thái đồ hoạ ──
        save() {
            this.stack.push({...this.st});
            this.ctx.save();
        }

        restore() {
            const s = this.stack.pop();
            if (s)
                this.st = s;
            this.ctx.restore();
        }

        translate(x, y) { this.ctx.translate(x, y); }
        rotate(a) { this.ctx.rotate(a); }
        scale(x, y) { this.ctx.scale(x, y); }
        setLineWidth(w) { this.ctx.lineWidth = w; }
        setAntialias(_m) { /* canvas không tắt được khử răng cưa */ }
        $dispose() { /* không cần giải phóng */ }

        setOperator(op) {
            this.st.op = op;
            if (op !== 'clear')
                this.ctx.globalCompositeOperation = op;
        }

        // ── nguồn màu ──
        setSourceRGBA(r, g, b, a) {
            const c = rgba(r, g, b, a);
            this.ctx.fillStyle = c;
            this.ctx.strokeStyle = c;
            this.st.src = {kind: 'color'};
            this.st.color = c;
        }

        setSource(g) {
            const cg = g.build(this.ctx);
            this.ctx.fillStyle = cg;
            this.ctx.strokeStyle = cg;
            this.st.src = {kind: 'grad'};
        }

        setSourceSurface(surf, x, y) {
            this.st.src = {kind: 'img', img: surf, x, y};
            this.st.nearest = false;
        }

        getSource() {
            const st = this.st;
            return {setFilter: f => { st.nearest = (f === 'nearest'); }};
        }

        // ── đường dẫn ──
        newPath() { this.ctx.beginPath(); }
        moveTo(x, y) { this.ctx.moveTo(x, y); }
        lineTo(x, y) { this.ctx.lineTo(x, y); }
        curveTo(a, b, c, d, e, f) { this.ctx.bezierCurveTo(a, b, c, d, e, f); }
        closePath() { this.ctx.closePath(); }
        rectangle(x, y, w, h) { this.ctx.rect(x, y, w, h); }

        arc(x, y, r, a0, a1) {
            if (r < 0)
                return;
            this.ctx.arc(x, y, r, a0, a1);
        }

        // Cairo: fill / stroke / clip xoá đường dẫn; canvas thì không
        fill() {
            this._paintPath(false);
            this.ctx.beginPath();
        }

        fillPreserve() { this._paintPath(false); }

        stroke() {
            this._paintPath(true);
            this.ctx.beginPath();
        }

        _paintPath(stroke) {
            const ctx = this.ctx;
            if (this.st.op === 'clear') {
                ctx.globalCompositeOperation = 'destination-out';
                if (stroke) ctx.stroke(); else ctx.fill();
                ctx.globalCompositeOperation = 'source-over';
                return;
            }
            if (stroke) ctx.stroke(); else ctx.fill();
        }

        clip() {
            this.ctx.clip();
            this.ctx.beginPath();
        }

        // ── tô cả vùng (trong phạm vi clip) ──
        paint() { this.paintWithAlpha(1); }

        paintWithAlpha(a) {
            const ctx = this.ctx, st = this.st, src = st.src;
            if (st.op === 'clear') {
                ctx.save();
                ctx.setTransform(1, 0, 0, 1, 0, 0);
                ctx.clearRect(0, 0, this.W, this.H);
                ctx.restore();
                return;
            }
            ctx.globalAlpha = a;
            if (src.kind === 'img') {
                ctx.imageSmoothingEnabled = !st.nearest;
                ctx.drawImage(src.img.canvas, src.x, src.y);
                ctx.imageSmoothingEnabled = true;
            } else if (src.kind === 'group') {
                ctx.save();
                ctx.setTransform(1, 0, 0, 1, 0, 0);
                ctx.drawImage(src.canvas, 0, 0);
                ctx.restore();
            } else {
                ctx.save();
                ctx.setTransform(1, 0, 0, 1, 0, 0);
                ctx.fillRect(0, 0, this.W, this.H);
                ctx.restore();
            }
            ctx.globalAlpha = 1;
        }

        // tô màu hiện tại xuyên qua độ trong suốt của ảnh
        maskSurface(img, x, y) {
            const ctx = this.ctx;
            ctx.drawImage(silhouette(img, this.st.color), x, y);
        }

        // ── nhóm (lớp vẽ tạm) ──
        pushGroup() {
            const depth = this.groups.length;
            let c = this.pool[depth];
            if (!c)
                c = this.pool[depth] = makeCanvas(this.W, this.H).getContext('2d');
            c.setTransform(1, 0, 0, 1, 0, 0);
            c.globalCompositeOperation = 'source-over';
            c.globalAlpha = 1;
            c.clearRect(0, 0, this.W, this.H);
            c.setTransform(this.ctx.getTransform());
            this.groups.push({prev: this.ctx, prevSt: this.st, prevStack: this.stack});
            this.ctx = c;
            this.st = {src: {kind: 'color'}, nearest: false, op: 'source-over', color: 'rgba(0,0,0,1)'};
            this.stack = [];
        }

        popGroupToSource() {
            const g = this.groups.pop();
            const canvas = this.ctx.canvas;
            this.ctx = g.prev;
            this.st = g.prevSt;
            this.stack = g.prevStack;
            this.st.src = {kind: 'group', canvas};
        }
    }

    return {
        ImageSurface, Context, LinearGradient, RadialGradient,
        Format: {ARGB32: 0},
        Operator: OPS,
        Antialias: {NONE: 'none'},
        Filter: {NEAREST: 'nearest'},
    };
})();
