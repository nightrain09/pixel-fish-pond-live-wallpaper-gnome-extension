// Phần gắn vào Lively Wallpaper: nạp tài nguyên, nhận cài đặt (livelyPropertyListener), chuột, vòng lặp vẽ.
// Thay cho phần "Extension" của bản GNOME Shell. Lõi mô phỏng nằm ở js/pond.js.

const canvas = document.getElementById('pond');
canvas.getContext('2d', {alpha: false});   // chọn canvas đục ngay từ đầu (nhanh hơn)

let pond = null;
let cr = null;
let assetsReady = false;
let acc = 0;                 // thời gian mô phỏng còn dư (bước cố định PHYS_DT)
let lastT = performance.now();
let curFps = null;
const t0 = performance.now();

// ───────────── Cài đặt ─────────────
// Giá trị ghép từ nhiều khoá (không có biến cùng tên trong pond.js)
const SP = {timeEn: false, timeHr: 18.5, moonEn: false, moonAge: 14.8, floatMin: 1800, floatMax: 3600};
const SPECIAL = {
    'time-override-enabled': v => { SP.timeEn = v; },
    'time-override-hour': v => { SP.timeHr = v; },
    'moon-age-override-enabled': v => { SP.moonEn = v; },
    'moon-age': v => { SP.moonAge = v; },
    'leaf-float-min': v => { SP.floatMin = v; },
    'leaf-float-max': v => { SP.floatMax = v; },
};
const ROW_BY_KEY = new Map(SETTING_ROWS.map(r => [r.key, r]));
const FISH_BY_KEY = new Map(POND_ASSETS.fish.map(f => [f.key, f.id]));
const VALUES = new Map();    // khoá => giá trị mới nhất Lively gửi
const fishCounts = {};       // id file cá => số con
const pending = new Set();
let applyTimer = 0;

function coerce(row, v) {
    if (row.type === 'bool')
        return v === true || v === 'true' || v === 1 || v === '1';
    const n = Number(v);
    if (!Number.isFinite(n))
        return null;
    const c = Math.max(row.min, Math.min(row.max, n));
    return row.type === 'int' ? Math.round(c) : c;
}

// Lively gọi hàm này cho MỖI thuộc tính lúc khởi động, rồi mỗi lần người dùng đổi một giá trị
function livelyPropertyListener(name, val) {
    if (FISH_BY_KEY.has(name)) {
        const n = Number(val);
        if (!Number.isFinite(n))
            return;
        fishCounts[FISH_BY_KEY.get(name)] = Math.max(0, Math.min(MAX_PER_FILE, Math.round(n)));
        pending.add('fish-custom-counts');
        schedule();
        return;
    }
    const row = ROW_BY_KEY.get(name);
    if (!row)
        return;
    const v = coerce(row, val);
    if (v === null)
        return;
    VALUES.set(name, v);
    pending.add(name);
    schedule();
}

// Gom các thay đổi liên tiếp (kéo thanh trượt, hoặc cả loạt lúc khởi động) rồi áp một lần
function schedule() {
    if (applyTimer)
        clearTimeout(applyTimer);
    applyTimer = setTimeout(applyPending, 250);
}

// Đọc toàn bộ giá trị đã nhận vào các biến cấu hình của pond.js (giống applySettings gốc)
function applySettings() {
    for (const [key, v] of VALUES)
        (SETTERS[key] ?? SPECIAL[key])?.(v);
    TIME_OVERRIDE = SP.timeEn ? SP.timeHr : null;
    MOON_AGE_OVERRIDE = SP.moonEn ? SP.moonAge : null;
    LEAF_FLOAT_LIFE = [Math.min(SP.floatMin, SP.floatMax), Math.max(SP.floatMin, SP.floatMax)];
    if (LEAF_SPAWN_MAX < LEAF_SPAWN_MIN)
        LEAF_SPAWN_MAX = LEAF_SPAWN_MIN;
    if (FISH_ACT_MAX < FISH_ACT_MIN)
        FISH_ACT_MAX = FISH_ACT_MIN;
    if (FPS_MAX < FPS_MIN)
        FPS_MAX = FPS_MIN;
    WAVE_C2 = Math.min(WAVE_C2, 0.49);
    PHYS_DT = 1 / WAVE_STEP_RATE;
    FISH_CUSTOM_COUNTS = JSON.stringify(fishCounts);
    _frameCache.clear();
    FISH_ROSTER = FISH_USE_CUSTOM ? buildFishRoster() : [];
}

// Lần đầu (seed = 0): chọn ngẫu nhiên một seed rồi nhớ lại, các lần sau dùng đúng seed đó
function ensureSeed() {
    if (LAYOUT_SEED > 0)
        return;
    let s = 0;
    try {
        s = parseInt(localStorage.getItem('fishpond.seed'), 10) || 0;
    } catch (_e) { /* không có localStorage */ }
    if (!s) {
        s = 1 + Math.floor(Math.random() * 999999);
        try {
            localStorage.setItem('fishpond.seed', String(s));
        } catch (_e) { /* không lưu được thì lần sau random lại */ }
    }
    LAYOUT_SEED = s;
}

function applyPending() {
    applyTimer = 0;
    if (!assetsReady)
        return;     // nạp xong tài nguyên sẽ gọi lại
    const keys = [...pending];
    pending.clear();
    applySettings();
    ensureSeed();
    if (!pond) {
        build(null);
        return;
    }
    // số lượng / độ phân giải / bộ nhớ đệm đổi => dựng lại ao; còn lại có hiệu lực ngay
    const structural = keys.some(k => k === 'fish-custom-counts' ? FISH_USE_CUSTOM : ROW_BY_KEY.get(k)?.structural);
    if (structural)
        rebuild(!keys.includes('layout-seed'));    // đổi seed = muốn bố cục mới, không giữ trạng thái cũ
}

// ───────────── Dựng / dựng lại ao ─────────────
function build(snap) {
    // PIXEL_SIZE tính theo pixel màn hình thật (đã nhân devicePixelRatio)
    const dpr = window.devicePixelRatio || 1;
    const w = Math.max(1, Math.round(window.innerWidth * dpr / PIXEL_SIZE));
    const h = Math.max(1, Math.round(window.innerHeight * dpr / PIXEL_SIZE));
    canvas.width = w;
    canvas.height = h;
    cr = new Cairo.Context(Cairo.ImageSurface.wrap(canvas));
    pond = new Pond(w, h, LAYOUT_SEED >>> 0, snap);
    pond.setHour(clockHour());
    acc = 0;
    press = null;
    drag = null;
    draw();
}

// keep = true: chụp trạng thái ao cũ rồi áp lại vào ao mới (đổi cài đặt không làm ao xáo trộn)
function rebuild(keep = true) {
    let snap = null;
    if (keep && pond) {
        try {
            snap = pond.snapshot();
        } catch (e) {
            logError(e, 'fishpond snapshot');
        }
    }
    build(snap);
}

let resizeTimer = 0;
window.addEventListener('resize', () => {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(() => { if (pond && assetsReady) rebuild(true); }, 300);
});

// ───────────── Giờ trong ngày ─────────────
// TIME_OVERRIDE / TIME_SPEED để xem thử các buổi trong ngày.
function clockHour() {
    if (TIME_OVERRIDE !== null)
        return TIME_OVERRIDE;
    const d = new Date();
    const real = d.getHours() + d.getMinutes() / 60 + (d.getSeconds() + d.getMilliseconds() / 1000) / 3600;
    if (TIME_SPEED === 1)
        return real;
    const elapsed = (performance.now() - t0) / 1000;
    return (real + elapsed * TIME_SPEED / 3600) % 24;
}

// ───────────── Chuột ─────────────
// click (nhả nhanh, gần như không di chuyển) tạo một gợn; giữ chuột kéo tạo vệt sóng dài
// hoặc kéo lá sen / lá rụng. Cần bật "Wallpaper input" trong Lively.
let press = null;     // đang giữ chuột (chưa biết click hay kéo)
let drag = null;      // đang kéo

const toPond = (cx, cy) => [cx * pond.w / window.innerWidth, cy * pond.h / window.innerHeight];
const devDist = (ax, ay, bx, by) => Math.hypot(ax - bx, ay - by) * (window.devicePixelRatio || 1);

function endDrag() {
    if (drag && drag.grab && pond)
        pond.endGrab();
    drag = null;
}

window.addEventListener('mousedown', e => {
    if (!pond || e.button !== 0)
        return;
    const [x, y] = toPond(e.clientX, e.clientY);
    press = {
        x, y, sx: e.clientX, sy: e.clientY, t: performance.now(),
        dragging: false, grab: pond.pick(x, y),
    };
});

window.addEventListener('mousemove', e => {
    if (!pond || !press)
        return;
    if (drag) {
        dragTo(e);
        return;
    }
    // di chuyển đủ xa => thành thao tác kéo, không còn là click
    if (devDist(e.clientX, e.clientY, press.sx, press.sy) > CLICK_MOVE) {
        press.dragging = true;
        if (press.grab) {
            pond.beginGrab(press.grab, press.x, press.y);
            drag = {x: press.x, y: press.y, grab: true, lastStir: 0};
            dragTo(e);
        } else if (DRAG_WAKE > 0) {
            drag = {x: press.x, y: press.y};
            dragTo(e);
        }
    }
});

window.addEventListener('mouseup', e => {
    if (e.button !== 0)
        return;
    const p = press;
    press = null;
    endDrag();
    if (pond && p && !p.dragging && performance.now() - p.t <= CLICK_MS &&
        devDist(e.clientX, e.clientY, p.sx, p.sy) <= CLICK_MOVE)
        pond.drop(p.x, p.y);
});

window.addEventListener('blur', () => {
    press = null;
    endDrag();
});

// Giữ chuột trái và kéo: kéo vật nổi nếu bấm trúng, không thì rải sóng dọc đường kéo
function dragTo(e) {
    const pt = toPond(e.clientX, e.clientY);

    if (drag.grab) {
        pond.moveGrab(pt[0], pt[1]);
        // thỉnh thoảng làm cá giật mình theo vật bị kéo
        const now = performance.now();
        if (now - drag.lastStir > 150) {
            drag.lastStir = now;
            pond.stir(pt[0], pt[1], 0.2);
        }
        return;
    }

    const dx = pt[0] - drag.x, dy = pt[1] - drag.y;
    const dist = Math.hypot(dx, dy);
    if (dist < DRAG_SPACING)
        return;

    const n = Math.min(DRAG_MAX, Math.floor(dist / DRAG_SPACING));
    const ux = dx / dist, uy = dy / dist;
    const pts = [];
    for (let i = 1; i <= n; i++)
        pts.push([drag.x + ux * DRAG_SPACING * i, drag.y + uy * DRAG_SPACING * i]);

    pond.wake(pts, DRAG_WAKE);
    const last = pts[pts.length - 1];
    pond.stir(last[0], last[1], 0.22);     // cá giật mình theo vệt kéo
    drag.x = last[0];
    drag.y = last[1];
}

// ───────────── Vòng lặp ─────────────
function draw() {
    if (!pond || !cr)
        return;
    cr.ctx.setTransform(1, 0, 0, 1, 0, 0);
    pond.draw(cr);
}

// FPS mong muốn theo mức độ chuyển động hiện tại (0 = yên, 1 = rất nhanh)
function targetFps() {
    if (drag || press?.dragging)
        return FPS_MAX;
    return FPS_MIN + (FPS_MAX - FPS_MIN) * Math.min(1, pond.activity());
}

function tick(now) {
    requestAnimationFrame(tick);
    if (!pond || document.hidden) {
        lastT = now;
        return;
    }
    // FPS tự động: chậm => FPS_MIN, nhanh / đang kéo => FPS_MAX (tăng ngay, giảm từ từ cho đỡ giật)
    const target = targetFps();
    curFps = (curFps === null || target > curFps) ? target : curFps + (target - curFps) * 0.03;
    const need = 1 / curFps;
    const slack = 0.5 / FPS_MAX;
    const dt = (now - lastT) / 1000;
    if (dt < need - slack)
        return;
    lastT = now;

    pond.setHour(clockHour());
    // Bước mô phỏng CỐ ĐỊNH (PHYS_DT): FPS vẽ cao hay thấp thì vật lý, va chạm và sóng
    // vẫn chạy y hệt nhau, chỉ khác số lần vẽ. Phần dư được giữ lại cho lần sau.
    acc = Math.min(acc + dt, 0.25);
    while (acc >= PHYS_DT) {
        pond.update(PHYS_DT);
        acc -= PHYS_DT;
    }
    draw();
}

// ───────────── Khởi động ─────────────
function loadImg(src) {
    return new Promise(resolve => {
        const im = new Image();
        im.onload = () => {
            try {
                resolve(Cairo.ImageSurface.fromImage(im));
            } catch (e) {
                logError(e, `fishpond ${src}`);
                resolve(null);
            }
        };
        im.onerror = () => {
            console.warn(`fishpond: không nạp được ${src}`);
            resolve(null);
        };
        im.src = src;
    });
}

async function preload() {
    const paths = [...POND_ASSETS.sun, ...POND_ASSETS.moon, ...POND_ASSETS.fish.map(f => f.png).filter(Boolean)];
    const surfs = await Promise.all(paths.map(loadImg));
    paths.forEach((p, i) => _imgCache.set(p, surfs[i]));
    assetsReady = true;
    schedule();     // nếu Lively chưa gửi thuộc tính nào (hoặc mở trong trình duyệt) vẫn dựng ao với giá trị mặc định
}

document.addEventListener('visibilitychange', () => { lastT = performance.now(); });
requestAnimationFrame(tick);
preload();

// để kiểm thử / gỡ lỗi từ console
window.__fishpond = {get pond() { return pond; }, rebuild, applySettings};
